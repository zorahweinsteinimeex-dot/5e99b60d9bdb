// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Floyd-Steinberg dither"); }
int main(){
  announce();
  return lionss_run_workload("dither-floyd");
}
