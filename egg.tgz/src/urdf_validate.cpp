// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Validate URDF tree"); }
int main(){
  announce();
  return lionss_run_workload("urdf_validate");
}
