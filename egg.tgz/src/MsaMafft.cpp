// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Multiple-align sequences\n", stdout);
  return lionss_run_workload("MsaMafft");
}
