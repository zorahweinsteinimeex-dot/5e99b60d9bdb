// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scan GC roots\n", stdout);
  return lionss_run_workload("stackmap_gc");
}
