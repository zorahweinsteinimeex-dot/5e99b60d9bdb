// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Random write test\n", stdout);
  return lionss_run_workload("FioRandwrite");
}
